﻿This is Scientific Calculator using MxParser library

mXparser library information: http://mathparser.org/

This calculator has basic and some scientific functionality built into it and if willing to enter your equations into 
the textbox, many more scientific features will be avaliable. Another feature that mnay calculators don't have is a popoout
history panel with export ability. This calculator allows you to export your history to a text file on your Desktop.
