﻿using Quartz;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for Email
/// </summary>
public class Email : IJob
{
    public Email()
    {
        //
        // TODO: Add constructor logic here
        //
    }

    public void Execute(IJobExecutionContext context)
    {
        JobKey key = context.JobDetail.Key;
        JobDataMap dataMap = context.JobDetail.JobDataMap;

        string Email = dataMap.GetString("Email");
        string Body = dataMap.GetString("Body");
    }

    public void SendEmail(string Email, string Body)
    {
        //Need to implement code here for sending emails
    }
}