﻿using Quartz;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Web;

/// <summary>
/// Summary description for Jobs
/// </summary>
public class Jobs : IJob
{
    
    public void Execute(IJobExecutionContext context)
    {
        JobKey key = context.JobDetail.Key;
        JobDataMap dataMap = context.JobDetail.JobDataMap;

        string URL = dataMap.GetString("URL");

        HitRequestSite(URL);
    }

    public void HitRequestSite(string URL)
    {
        WebClient client = new WebClient();
        client.DownloadData(URL);
    }

}