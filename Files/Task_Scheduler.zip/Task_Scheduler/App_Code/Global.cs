﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for Global
/// </summary>
public class Global
{
    public Global()
    {
        //
        // TODO: Add constructor logic here
        //
    }
    /// <summary>
    /// Used to write exceptions, and scheduled tasks to a textfile
    /// </summary>
    /// <param name="str"></param>
    public static void WriteToTextFile(string str)
    {
        string FileName = "SchedulerSystemErrorTxt.txt";
        string path = "C:\\inetpub\\wwwroot\\Task_Scheduler\\Images";
        if (File.Exists(Path.Combine(path,FileName)) == true )
        {
            using (StreamWriter streamWriter = File.AppendText(Path.Combine(path, FileName)))
            {
                streamWriter.WriteLine(str);
            }
        }
        else
        {
            using (StreamWriter streamWriter = File.CreateText(Path.Combine(path, FileName)))
            {
                streamWriter.WriteLine(str);
            }
        }
    }

    /// <summary>
    /// Returns a Dataset with all of the tasks needed to be scheduled
    /// </summary>
    /// <returns></returns>
    public static DataSet GetTasks()
    {
        using (SqlConnection conn = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["TASK"].ConnectionString))
        {
            conn.Open();
            string sql = "select JobID,TriggerID, Time,URL FROM TASK";
            SqlCommand cmd = new SqlCommand(sql, conn);
            SqlDataAdapter DA = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            DA.Fill(ds, "Tasks");
            conn.Close();
            return ds;
        }
    }

    /// <summary>
    /// Used Only when the Application is started to initiate the tasks
    /// </summary>
    public static void StartUpSchedule()
    {
        DataSet ds = GetTasks();
        foreach (DataRow row in ds.Tables["Tasks"].Rows)
        {
            NewJob JobObj = (NewJob)JobScheduler.CreateJob((string)row["JobID"], (string)row["TriggerID"], (string)row["URL"], (string)row["Time"]);
            JobScheduler.ScheduleJob(JobObj.job, JobObj.trigger);
        }
    }

    public static int GetMaxID()
    {
        using (SqlConnection conn = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["TASK"].ConnectionString))
        {
            conn.Open();
            string sql = "Select Max(TaskID) FROM TASK";
            SqlCommand cmd = new SqlCommand(sql, conn);
            conn.Close();
            return (int)cmd.ExecuteScalar();

        }
    }

    public static void AddTaskToDB(string JobID, string TriggerID, string URL, string Time)
    {
        using (SqlConnection conn = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["TASK"].ConnectionString))
        {
            conn.Open();
            string sql = "insert into TASK (JobID, TriggerID, URL, Time) Values (@JobID, @TriggerID, @URL, @Time)";
            SqlCommand cmd = new SqlCommand(sql, conn);
            cmd.Parameters.Add(new SqlParameter("@JobID", JobID));
            cmd.Parameters.Add(new SqlParameter("@TriggerID", TriggerID));
            cmd.Parameters.Add(new SqlParameter("@URL", URL));
            cmd.Parameters.Add(new SqlParameter("@Time", Time));
            cmd.ExecuteNonQuery();
            conn.Close();

        }
    }
}