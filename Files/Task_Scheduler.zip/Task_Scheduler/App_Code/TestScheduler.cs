﻿using Quartz;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Web;

/// <summary>
/// Summary description for TestScheduler
/// </summary>
public class TestScheduler
{
    public TestScheduler()
    {
        //
        // TODO: Add constructor logic here
        //
    }

    /// <summary>
    /// Creates a Job and Trigger for Scheduling
    /// </summary>
    /// <param name="JobIdentity">Job Name</param>
    /// <param name="TriggerIdentity">Trigger Name</param>
    /// <param name="URL">URL to Poke</param>
    /// <param name="ScheduledTime">Input String for the Trigger Time</param>
    /// <returns>an Object that can be</returns>
    public static object CreateTestJob()
    {

        IJobDetail job = JobBuilder.Create<HelloJob>()
                    .WithIdentity("Testjob1", "group1")
                    .Build();

        ITrigger trigger = TriggerBuilder.Create()
                     .WithIdentity("Testtrigger01", "group1")
                     .StartNow()
                     .WithSimpleSchedule(x => x
                         .WithIntervalInSeconds(10)
                         .WithRepeatCount(2))
                     .Build();

        NewJob JobObj = new NewJob(job, trigger);

        return JobObj;

    }
    public class HelloJob : IJob
    {
        public void Execute(IJobExecutionContext context)
        {
            System.Diagnostics.Debug.WriteLine("Greetings from HelloJob!");
            WebClient client = new WebClient();
            client.DownloadData("http://www.jccap.org/test_script.aspx");
        }
    }
}