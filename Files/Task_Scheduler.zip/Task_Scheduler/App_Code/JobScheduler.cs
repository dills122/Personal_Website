﻿using Quartz;
using Quartz.Impl;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;


//""

/// <summary>
/// Summary description for JobScheduler
/// </summary>
public class JobScheduler
{
    private static IScheduler sc;

    

    /// <summary>
    /// Creates a Job and Trigger for Scheduling
    /// </summary>
    /// <param name="JobIdentity">Job Name</param>
    /// <param name="TriggerIdentity">Trigger Name</param>
    /// <param name="URL">URL to Poke</param>
    /// <param name="ScheduledTime">Input String for the Trigger Time</param>
    /// <returns>an Object that can be</returns>
    public static object CreateJob(string JobIdentity, string TriggerIdentity, string URL, string ScheduledTime)
    {
        IJobDetail job = JobBuilder.Create<Jobs>()
            .WithIdentity(JobIdentity)
            .UsingJobData("URL", URL)
            .Build();

        ITrigger trigger = TriggerBuilder.Create()
                                         .ForJob(job)
                                         .WithIdentity(TriggerIdentity)
                                         .WithCronSchedule(ScheduledTime)
                                         .Build();

        NewJob JobObj = new NewJob(job, trigger);

        return JobObj;

    }

    /// <summary>
    /// Used to Create a Job that will send an Email
    /// </summary>
    /// <param name="JobIdentity"></param>
    /// <param name="TriggerIdentity"></param>
    /// <param name="Email"></param>
    /// <param name="body"></param>
    /// <param name="ScheduledTime"></param>
    /// <returns></returns>
    public static object CreateEmailJob(string JobIdentity, string TriggerIdentity, string Email, string Body, string ScheduledTime)
    {
        IJobDetail job = JobBuilder.Create<Jobs>()
            .WithIdentity(JobIdentity)
            .UsingJobData("Email", Email)
            .UsingJobData("Body", Body)
            .Build();

        ITrigger trigger = TriggerBuilder.Create()
                                         .ForJob(job)
                                         .WithIdentity(TriggerIdentity)
                                         .WithCronSchedule(ScheduledTime)
                                         .Build();

        NewJob JobObj = new NewJob(job, trigger);

        return JobObj;

    }

    /// <summary>
    /// Allows a User to Schedule a Task
    /// </summary>
    /// <param name="job">Job to be scheduled</param>
    /// <param name="trigger">Trigger that starts the Scheduled Job</param>
    public static int ScheduleJob(IJobDetail job, ITrigger trigger)
    {
        try
        {
            sc.ScheduleJob(job, trigger);

            System.Diagnostics.Debug.WriteLine("Job Scheduled Successfully");
            Global.WriteToTextFile("Job Scheduled Successfully" + DateTime.Now.ToString());
            Global.WriteToTextFile(job.ToString());
            return 1;
        }
        catch (Exception ex)
        {
            System.Diagnostics.Debug.WriteLine(ex);
            Global.WriteToTextFile(ex.ToString());
            return 0;
        }
        
    }

    /// <summary>
    /// Starts the Scheduler on Application Load Via Global.asax
    /// </summary>
    public static void Start()
    {


        ISchedulerFactory sf = new StdSchedulerFactory();
        sc = sf.GetScheduler();
        sc.Start();

    }
    /// <summary>
    /// Ends the Scheduler
    /// </summary>
    public static void End()
    {
        if (sc.IsShutdown == false)
        {
            sc.Shutdown();
            System.Diagnostics.Debug.WriteLine("Scheduler ShutDown");
        }
    }
}