﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class NewTask : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {


    }
    /// <summary>
    /// Method that creates the jobs
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void Submitbtn_Click(object sender, EventArgs e)
    {
        string TriggerID = "";
        string JobID = "";

        string TriggerTime = (string)TriggerTimeddl.SelectedValue;
        string URLText = "";

        //Checks URL to make sure it isn't Empty or in bad format
        if (Uri.IsWellFormedUriString(URLtxt.Text, UriKind.Absolute) == true && String.IsNullOrEmpty(URLtxt.Text) == false)
        {
             URLText = (string)URLtxt.Text;

            int Max = (Global.GetMaxID() + 1) * 100;
            JobID = "Job" + Max;
            TriggerID = "Trig" + Max;
            Global.AddTaskToDB(JobID, TriggerID, URLText, TriggerTime);

            //Creates the Job and schedules it
            NewJob JobObj = (NewJob)JobScheduler.CreateJob(JobID, TriggerID, URLText, TriggerTime);
            int i = JobScheduler.ScheduleJob(JobObj.job, JobObj.trigger);
            if (i == 1)
            {
                JobScheduledlb.Visible = true;
            }
            else
            {
                JobScheduledlb.Visible = true;
                JobScheduledlb.Text = "Unsuccessful job!";
            }

        }
        else
        {
            Errorlb.Text = "URL was not in good format";
        }
        
    }

    /// <summary>
    /// Only for Test purposes, If you need to test you will need to change the visiblilty of the Testpnl
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void testbtn_Click(object sender, EventArgs e)
    {

        NewJob TestJob =  (NewJob)TestScheduler.CreateTestJob();

        JobScheduler.ScheduleJob(TestJob.job, TestJob.trigger);
    }


}