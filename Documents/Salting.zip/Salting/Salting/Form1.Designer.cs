﻿namespace Salting
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.PlainPass = new System.Windows.Forms.TextBox();
            this.Hashbtn = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.HashedPass = new System.Windows.Forms.TextBox();
            this.Checktxt = new System.Windows.Forms.TextBox();
            this.Checkbtn = new System.Windows.Forms.Button();
            this.Checklb = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(13, 13);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(79, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Plain Password";
            // 
            // PlainPass
            // 
            this.PlainPass.Location = new System.Drawing.Point(13, 30);
            this.PlainPass.Name = "PlainPass";
            this.PlainPass.Size = new System.Drawing.Size(179, 20);
            this.PlainPass.TabIndex = 1;
            // 
            // Hashbtn
            // 
            this.Hashbtn.Location = new System.Drawing.Point(198, 30);
            this.Hashbtn.Name = "Hashbtn";
            this.Hashbtn.Size = new System.Drawing.Size(75, 20);
            this.Hashbtn.TabIndex = 2;
            this.Hashbtn.Text = "Hash";
            this.Hashbtn.UseVisualStyleBackColor = true;
            this.Hashbtn.Click += new System.EventHandler(this.Hashbtn_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(13, 83);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(93, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "Hashed Password";
            // 
            // HashedPass
            // 
            this.HashedPass.Location = new System.Drawing.Point(13, 100);
            this.HashedPass.Multiline = true;
            this.HashedPass.Name = "HashedPass";
            this.HashedPass.Size = new System.Drawing.Size(259, 149);
            this.HashedPass.TabIndex = 4;
            // 
            // Checktxt
            // 
            this.Checktxt.Location = new System.Drawing.Point(13, 264);
            this.Checktxt.Name = "Checktxt";
            this.Checktxt.Size = new System.Drawing.Size(179, 20);
            this.Checktxt.TabIndex = 5;
            // 
            // Checkbtn
            // 
            this.Checkbtn.Location = new System.Drawing.Point(198, 264);
            this.Checkbtn.Name = "Checkbtn";
            this.Checkbtn.Size = new System.Drawing.Size(75, 20);
            this.Checkbtn.TabIndex = 6;
            this.Checkbtn.Text = "Check Hash";
            this.Checkbtn.UseVisualStyleBackColor = true;
            this.Checkbtn.Click += new System.EventHandler(this.Checkbtn_Click);
            // 
            // Checklb
            // 
            this.Checklb.AutoSize = true;
            this.Checklb.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Checklb.Location = new System.Drawing.Point(113, 294);
            this.Checklb.Name = "Checklb";
            this.Checklb.Size = new System.Drawing.Size(0, 22);
            this.Checklb.TabIndex = 7;
            this.Checklb.Visible = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 327);
            this.Controls.Add(this.Checklb);
            this.Controls.Add(this.Checkbtn);
            this.Controls.Add(this.Checktxt);
            this.Controls.Add(this.HashedPass);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.Hashbtn);
            this.Controls.Add(this.PlainPass);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Hashing Passwords";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox PlainPass;
        private System.Windows.Forms.Button Hashbtn;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox HashedPass;
        private System.Windows.Forms.TextBox Checktxt;
        private System.Windows.Forms.Button Checkbtn;
        private System.Windows.Forms.Label Checklb;
    }
}

