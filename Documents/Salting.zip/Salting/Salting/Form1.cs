﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Salting
{
    public partial class Form1 : Form
    {
        public string Salt = "";
        public Form1()
        {
            InitializeComponent();
        }

        /// <summary>
        /// Hashes and Salts the String
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Hashbtn_Click(object sender, EventArgs e)
        {
            Salt = CreateRandomSalt();
            HashedPass.Text = Hash(PlainPass.Text, Salt);
        }
        /// <summary>
        /// Creates Random Salt for a hashed password
        /// </summary>
        /// <returns></returns>
        static string CreateRandomSalt()
        {
            string mix = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#$%^&*()_+=][}{<>";
            string salt = "";
            Random rnd = new Random();
            StringBuilder sb = new StringBuilder();
            for (int i = 1; i <100; i++)
            {
                int x = rnd.Next(0, mix.Length - 1);
                salt += (mix.Substring(x, 1));
            }
            return salt;
        }
        /// <summary>
        /// Hashes the password
        /// </summary>
        /// <param name="input"></param>
        /// <param name="salt"></param>
        /// <returns></returns>
        static string Hash(string input, string salt)
        {
            Byte[] convertedToBytes = Encoding.UTF8.GetBytes(input + salt);
            HashAlgorithm hashType = new SHA512Managed();
            Byte[] hashBytes = hashType.ComputeHash(convertedToBytes);
            string hashedResults = Convert.ToBase64String(hashBytes);

            
            return hashedResults;
        }
        /// <summary>
        /// Compares the strings after hashing
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Checkbtn_Click(object sender, EventArgs e)
        {
            if (HashedPass.Text != "")
            {
                string CheckedHash = Hash(Checktxt.Text, Salt);

                bool result = HashedPass.Text.ToString().Equals(CheckedHash, StringComparison.Ordinal);
                if (result == true )
                {
                    Checklb.Text = "Match!";
                    Checklb.ForeColor = Color.Green;
                    Checklb.Visible = true;
                
                }
                else
                {
                    Checklb.Text = "Wrong!";
                    Checklb.ForeColor = Color.Red;
                    Checklb.Visible = true;
                }
            }
        }
    }
}
